#ifndef _BUZZ_H_
#define _BUZZ_H_



void buzz_init(void);
#endif


